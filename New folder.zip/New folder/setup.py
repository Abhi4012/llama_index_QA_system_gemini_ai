from setuptools import find_packages, setup

setup(
    name = 'QApplication',
    version= '0.0.1',
    author= 'abhishek singh',
    author_email= 'ak352319@gmail.com',
    packages= find_packages(),
    install_requires = []

)